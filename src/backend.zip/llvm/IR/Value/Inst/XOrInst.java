package llvm.IR.Value.Inst;

public class XOrInst extends Instruction{
    // 异或指令：<result> = xor <ty> <op1>, <op2>
    // 返回 true 如果两个操作数不同（一个是 true，另一个是 false），否则返回 false
}
