package llvm.IR.Value.Inst;

public class LoadInst extends Instruction{
}
