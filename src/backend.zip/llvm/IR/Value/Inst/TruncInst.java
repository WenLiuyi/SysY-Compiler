package llvm.IR.Value.Inst;

public class TruncInst extends Instruction{
    public TruncInst(){
        super();
    }
}
