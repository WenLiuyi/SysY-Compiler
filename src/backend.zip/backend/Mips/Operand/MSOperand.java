package backend.Mips.Operand;

public interface MSOperand {
    public boolean needsAllocate();
}

