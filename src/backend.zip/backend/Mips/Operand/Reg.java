package backend.Mips.Operand;

public interface Reg extends MSOperand{
}
