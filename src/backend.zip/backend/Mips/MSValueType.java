package backend.Mips;

public enum MSValueType {
    word,
    _byte,
    str,
    array,
}
