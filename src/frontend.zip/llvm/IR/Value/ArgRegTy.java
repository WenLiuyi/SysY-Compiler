package llvm.IR.Value;

public class ArgRegTy {
}
