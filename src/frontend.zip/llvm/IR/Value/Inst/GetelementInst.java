package llvm.IR.Value.Inst;

public class GetelementInst extends Instruction{
    public GetelementInst() {}
}
