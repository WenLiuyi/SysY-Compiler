package llvm.IR.Value.Inst;

public class AllocaInst extends Instruction{
}
