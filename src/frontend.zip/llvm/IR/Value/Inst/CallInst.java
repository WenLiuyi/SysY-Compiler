package llvm.IR.Value.Inst;

public class CallInst extends Instruction{
}
