package llvm.IR.Value.Inst;

public class JumpInst extends Instruction{
}
