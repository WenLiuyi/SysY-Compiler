package llvm.IR.Value;

public class ConstantData {
}
