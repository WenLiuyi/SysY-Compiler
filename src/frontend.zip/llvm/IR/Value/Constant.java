package llvm.IR.Value;

public class Constant {
}
