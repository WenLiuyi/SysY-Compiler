package llvm.IR.Value.Inst;

public class UnaryInst extends Instruction{
}
