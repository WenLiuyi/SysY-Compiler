package llvm.IR.Value.Inst;

public class ZextInst extends Instruction{
    public ZextInst() {
        super();
    }
}
