package llvm.IR.Value.Inst;

public class BranchInst extends Instruction{
}
