package llvm.IR.Value.Inst;

public class ReturnInst extends Instruction{
}
