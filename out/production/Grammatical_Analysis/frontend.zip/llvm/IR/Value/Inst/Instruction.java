package llvm.IR.Value.Inst;

import llvm.IR.Value.*;

public class Instruction extends User{
    public Instruction(){
        super();
    }
}
