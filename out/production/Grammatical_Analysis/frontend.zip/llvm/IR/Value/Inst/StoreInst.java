package llvm.IR.Value.Inst;

public class StoreInst extends Instruction{
    public StoreInst(){
        super();
    }
    // store <ty> <value>, ptr <pointer>
    // usersList中：第一个是value，第二个是pointer
}
